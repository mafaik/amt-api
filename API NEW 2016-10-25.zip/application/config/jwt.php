<?php

$config['jwt'] = [
    'key' => 'WQZJuIHjJ^Lk',
    'issuer' => 'http://127.0.0.1',
    'http_header_name' => 'AMT-JWT'
];